import { SlashCommandBuilder, EmbedBuilder } from "discord.js";

const API = "https://api-web.nhle.com/v1";

export const commands = [
  new SlashCommandBuilder().setName("nhl").setDescription("Informations NHL.")
    .addSubcommand(s => s.setName("scores").setDescription("Voir les scores du jour."))
    .addSubcommand(s => s.setName("standings").setDescription("Voir le classement NHL."))
    .addSubcommand(s => s.setName("info").setDescription("Informations sur une équipe.").addStringOption(o => o.setName("equipe").setDescription("Abréviation, ex. MTL").setRequired(true)))
    .addSubcommand(s => s.setName("predict").setDescription("Créer un pronostic NHL.").addStringOption(o => o.setName("match").setDescription("Match ou description").setRequired(true)))
];

async function getJson(path) {
  const r = await fetch(`${API}${path}`);
  if (!r.ok) throw new Error(`NHL API ${r.status}`);
  return r.json();
}

export async function handleNhl(interaction) {
  await interaction.deferReply();

  try {
    const sub = interaction.options.getSubcommand();

    if (sub === "scores") {
      const data = await getJson("/score/now");
      const games = (data.games || []).slice(0, 15);
      const text = games.length
        ? games.map(g => `${g.awayTeam?.abbrev || "?"} ${g.awayTeam?.score ?? "-"} — ${g.homeTeam?.score ?? "-"} ${g.homeTeam?.abbrev || "?"} — ${g.gameState || ""}`).join("\n")
        : "Aucun match trouvé.";
      return interaction.editReply({ embeds: [new EmbedBuilder().setTitle("NHL — Scores").setDescription(text)] });
    }

    if (sub === "standings") {
      const data = await getJson("/standings/now");
      const rows = (data.standings || []).slice(0, 15);
      const text = rows.map((t, i) => `${i + 1}. **${t.teamAbbrev?.default || "?"}** — ${t.points ?? 0} pts (${t.wins ?? 0}-${t.losses ?? 0}-${t.otLosses ?? 0})`).join("\n");
      return interaction.editReply({ embeds: [new EmbedBuilder().setTitle("NHL — Classement").setDescription(text || "Classement indisponible.")] });
    }

    if (sub === "info") {
      const team = interaction.options.getString("equipe").toUpperCase();
      const data = await getJson(`/club-stats/${team}/now`);
      return interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`NHL — ${team}`).setDescription(
        `Victoires : **${data.wins ?? "?"}**\nDéfaites : **${data.losses ?? "?"}**\nDéfaites OT : **${data.otLosses ?? "?"}**\nPoints : **${data.points ?? "?"}**`
      )] });
    }

    if (sub === "predict") {
      const match = interaction.options.getString("match");
      const prediction = Math.random() < 0.5 ? "Équipe A" : "Équipe B";
      return interaction.editReply(`**Pronostic NHL**\nMatch : ${match}\n\nPronostic aléatoire de démonstration : **${prediction}**\n\nCe pronostic n'est pas une garantie de résultat.`);
    }
  } catch (e) {
    return interaction.editReply("Impossible de récupérer les informations NHL pour le moment.");
  }
}

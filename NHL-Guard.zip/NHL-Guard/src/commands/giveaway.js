import {
  SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, EmbedBuilder
} from "discord.js";
import { loadDb, saveDb } from "../utils/db.js";

export const commands = [
  new SlashCommandBuilder().setName("giveaway").setDescription("Gestion des giveaways.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName("create").setDescription("Créer un giveaway.")
      .addStringOption(o => o.setName("prix").setDescription("Prix").setRequired(true))
      .addIntegerOption(o => o.setName("minutes").setDescription("Durée en minutes").setMinValue(1).setMaxValue(10080).setRequired(true))
    )
    .addSubcommand(s => s.setName("end").setDescription("Terminer un giveaway.")
      .addStringOption(o => o.setName("message_id").setDescription("ID du message").setRequired(true))
    )
];

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

export async function handleGiveaway(interaction) {
  const db = loadDb();

  if (interaction.options.getSubcommand() === "create") {
    const prize = interaction.options.getString("prix");
    const minutes = interaction.options.getInteger("minutes");
    const endsAt = Date.now() + minutes * 60_000;

    const embed = new EmbedBuilder()
      .setTitle("Giveaway NHL")
      .setDescription(`**Prix :** ${prize}\n\nClique sur le bouton pour participer.\nFin : <t:${Math.floor(endsAt / 1000)}:R>`)
      .setTimestamp(endsAt);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("giveaway_join").setLabel("Participer").setStyle(ButtonStyle.Success)
    );

    const message = await interaction.channel.send({ embeds: [embed], components: [row] });
    db.giveaways[message.id] = { channelId: interaction.channel.id, prize, endsAt, entries: [] };
    saveDb(db);
    return interaction.reply({ content: `Giveaway créé : ${message.url}`, ephemeral: true });
  }

  const id = interaction.options.getString("message_id");
  const giveaway = db.giveaways[id];
  if (!giveaway) return interaction.reply({ content: "Giveaway introuvable.", ephemeral: true });

  const winnerId = pick(giveaway.entries);
  giveaway.ended = true;
  giveaway.winnerId = winnerId || null;
  saveDb(db);
  return interaction.reply(winnerId ? `Le gagnant est <@${winnerId}> pour **${giveaway.prize}** !` : "Aucun participant.");
}

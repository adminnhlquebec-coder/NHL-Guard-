import {
  SlashCommandBuilder, PermissionFlagsBits, ChannelType,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder
} from "discord.js";
import { loadDb, saveDb } from "../utils/db.js";

export const commands = [
  new SlashCommandBuilder().setName("setup").setDescription("Configurer les éléments de base de NHL Guard.").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder().setName("serverinfo").setDescription("Afficher les informations du serveur."),
  new SlashCommandBuilder().setName("userinfo").setDescription("Afficher les informations d'un membre.").addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(false)),
  new SlashCommandBuilder().setName("role").setDescription("Ajouter ou retirer un rôle.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(s => s.setName("add").setDescription("Ajouter").addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true)).addRoleOption(o => o.setName("role").setDescription("Rôle").setRequired(true)))
    .addSubcommand(s => s.setName("remove").setDescription("Retirer").addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true)).addRoleOption(o => o.setName("role").setDescription("Rôle").setRequired(true))),
  new SlashCommandBuilder().setName("ticket").setDescription("Envoyer le panneau de création de tickets.").setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  new SlashCommandBuilder().setName("invites").setDescription("Voir les invitations attribuées à un membre.").addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(false))
];

export async function handleServer(interaction) {
  const db = loadDb();

  if (interaction.commandName === "setup") {
    const guild = interaction.guild;
    let welcome = guild.channels.cache.find(c => c.name === "bienvenue" && c.type === ChannelType.GuildText);
    if (!welcome) welcome = await guild.channels.create({ name: "bienvenue", type: ChannelType.GuildText });
    let logs = guild.channels.cache.find(c => c.name === "logs" && c.type === ChannelType.GuildText);
    if (!logs) logs = await guild.channels.create({ name: "logs", type: ChannelType.GuildText });
    let support = guild.channels.cache.find(c => c.name === "support" && c.type === ChannelType.GuildText);
    if (!support) support = await guild.channels.create({ name: "support", type: ChannelType.GuildText });

    db.config[guild.id] = { welcomeChannelId: welcome.id, logChannelId: logs.id, supportChannelId: support.id };
    saveDb(db);
    return interaction.reply({ content: `Configuration de base terminée.\nBienvenue : <#${welcome.id}>\nLogs : <#${logs.id}>\nSupport : <#${support.id}>`, ephemeral: true });
  }

  if (interaction.commandName === "serverinfo") {
    const g = interaction.guild;
    return interaction.reply({ embeds: [new EmbedBuilder().setTitle(g.name).addFields(
      { name: "Membres", value: `${g.memberCount}`, inline: true },
      { name: "Salons", value: `${g.channels.cache.size}`, inline: true },
      { name: "Créé le", value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true }
    ).setTimestamp()] });
  }

  if (interaction.commandName === "userinfo") {
    const user = interaction.options.getUser("membre") || interaction.user;
    const member = await interaction.guild.members.fetch(user.id);
    return interaction.reply({ embeds: [new EmbedBuilder().setTitle(user.tag).setThumbnail(user.displayAvatarURL()).addFields(
      { name: "ID", value: user.id },
      { name: "Compte", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>` },
      { name: "Arrivée", value: member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>` : "Inconnue" }
    )] });
  }

  if (interaction.commandName === "role") {
    const sub = interaction.options.getSubcommand();
    const member = interaction.options.getMember("membre");
    const role = interaction.options.getRole("role");
    if (!member || !role) return interaction.reply({ content: "Membre ou rôle introuvable.", ephemeral: true });
    if (role.position >= interaction.guild.members.me.roles.highest.position) return interaction.reply({ content: "Mon rôle est trop bas pour gérer ce rôle.", ephemeral: true });
    if (sub === "add") await member.roles.add(role);
    else await member.roles.remove(role);
    return interaction.reply({ content: `${sub === "add" ? "Rôle ajouté" : "Rôle retiré"} : ${role}.`, ephemeral: true });
  }

  if (interaction.commandName === "ticket") {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("ticket_support").setLabel("Créer un ticket").setStyle(ButtonStyle.Primary)
    );
    return interaction.reply({ content: "Utilise le bouton ci-dessous pour ouvrir un ticket.", components: [row] });
  }

  if (interaction.commandName === "invites") {
    const user = interaction.options.getUser("membre") || interaction.user;
    const count = db.invites[user.id]?.valid || 0;
    return interaction.reply(`**${user.tag}** a actuellement **${count} invitation(s) valide(s)**.`);
  }
}

import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder
} from "discord.js";
import { loadDb, saveDb } from "../utils/db.js";
import { logEvent } from "../utils/log.js";

export const commands = [
  new SlashCommandBuilder()
    .setName("ban").setDescription("Bannir un membre.")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),
  new SlashCommandBuilder()
    .setName("kick").setDescription("Expulser un membre.")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),
  new SlashCommandBuilder()
    .setName("timeout").setDescription("Mettre un membre en timeout.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true))
    .addIntegerOption(o => o.setName("minutes").setDescription("Durée en minutes").setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(false)),
  new SlashCommandBuilder()
    .setName("warn").setDescription("Donner un avertissement.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true))
    .addStringOption(o => o.setName("raison").setDescription("Raison").setRequired(true)),
  new SlashCommandBuilder()
    .setName("warnings").setDescription("Voir les avertissements d'un membre.")
    .addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(true)),
  new SlashCommandBuilder()
    .setName("clear").setDescription("Supprimer des messages.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName("nombre").setDescription("Nombre de messages").setMinValue(1).setMaxValue(100).setRequired(true))
];

export async function handleModeration(interaction) {
  const db = loadDb();

  if (interaction.commandName === "ban") {
    const member = interaction.options.getMember("membre");
    const user = interaction.options.getUser("membre");
    const reason = interaction.options.getString("raison") || "Aucune raison fournie.";
    if (!member?.bannable) return interaction.reply({ content: "Je ne peux pas bannir ce membre.", ephemeral: true });
    await member.ban({ reason });
    await interaction.reply(`**${user.tag}** a été banni. Raison : ${reason}`);
    await logEvent(interaction.guild, "Ban", `${user.tag} a été banni.`, [{ name: "Modérateur", value: interaction.user.tag }, { name: "Raison", value: reason }]);
  }

  if (interaction.commandName === "kick") {
    const member = interaction.options.getMember("membre");
    const user = interaction.options.getUser("membre");
    const reason = interaction.options.getString("raison") || "Aucune raison fournie.";
    if (!member?.kickable) return interaction.reply({ content: "Je ne peux pas expulser ce membre.", ephemeral: true });
    await member.kick(reason);
    await interaction.reply(`**${user.tag}** a été expulsé. Raison : ${reason}`);
    await logEvent(interaction.guild, "Kick", `${user.tag} a été expulsé.`, [{ name: "Modérateur", value: interaction.user.tag }, { name: "Raison", value: reason }]);
  }

  if (interaction.commandName === "timeout") {
    const member = interaction.options.getMember("membre");
    const minutes = interaction.options.getInteger("minutes");
    const reason = interaction.options.getString("raison") || "Aucune raison fournie.";
    if (!member?.moderatable) return interaction.reply({ content: "Je ne peux pas mettre ce membre en timeout.", ephemeral: true });
    await member.timeout(minutes * 60_000, reason);
    await interaction.reply(`**${member.user.tag}** est en timeout pour ${minutes} minute(s).`);
    await logEvent(interaction.guild, "Timeout", `${member.user.tag} a reçu un timeout.`, [{ name: "Durée", value: `${minutes} min` }, { name: "Raison", value: reason }]);
  }

  if (interaction.commandName === "warn") {
    const user = interaction.options.getUser("membre");
    const reason = interaction.options.getString("raison");
    db.warnings[user.id] ??= [];
    db.warnings[user.id].push({
      reason, moderatorId: interaction.user.id, at: new Date().toISOString()
    });
    saveDb(db);
    await interaction.reply(`**${user.tag}** a reçu un avertissement. Total : ${db.warnings[user.id].length}.`);
    await logEvent(interaction.guild, "Avertissement", `${user.tag} a reçu un avertissement.`, [{ name: "Raison", value: reason }]);
  }

  if (interaction.commandName === "warnings") {
    const user = interaction.options.getUser("membre");
    const warnings = db.warnings[user.id] || [];
    if (!warnings.length) return interaction.reply({ content: `${user.tag} n'a aucun avertissement.`, ephemeral: true });
    const text = warnings.slice(-10).map((w, i) => `**${i + 1}.** ${w.reason} — <@${w.moderatorId}>`).join("\n");
    return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`Avertissements — ${user.tag}`).setDescription(text).setColor(0xF5C542)] });
  }

  if (interaction.commandName === "clear") {
    const n = interaction.options.getInteger("nombre");
    const deleted = await interaction.channel.bulkDelete(n, true);
    return interaction.reply({ content: `J'ai supprimé ${deleted.size} message(s).`, ephemeral: true });
  }
}

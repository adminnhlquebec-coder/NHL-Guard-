import { commands as moderation } from "./moderation.js";
import { commands as server } from "./server.js";
import { commands as giveaway } from "./giveaway.js";
import { commands as xp } from "./xp.js";
import { commands as nhl } from "./nhl.js";

export const allCommands = [...moderation, ...server, ...giveaway, ...xp, ...nhl];

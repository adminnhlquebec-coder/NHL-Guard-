import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import { loadDb, saveDb } from "../utils/db.js";

export const commands = [
  new SlashCommandBuilder().setName("rank").setDescription("Voir son niveau ou celui d'un membre.").addUserOption(o => o.setName("membre").setDescription("Membre").setRequired(false)),
  new SlashCommandBuilder().setName("leaderboard").setDescription("Voir le classement XP.")
];

function levelFor(xp) { return Math.floor(Math.sqrt(xp / 100)); }

export async function handleXp(interaction) {
  const db = loadDb();

  if (interaction.commandName === "rank") {
    const user = interaction.options.getUser("membre") || interaction.user;
    const xp = db.xp[user.id]?.xp || 0;
    return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`Niveau de ${user.username}`).setDescription(`XP : **${xp}**\nNiveau : **${levelFor(xp)}**`)] });
  }

  const list = Object.entries(db.xp)
    .sort((a, b) => b[1].xp - a[1].xp)
    .slice(0, 10)
    .map(([id, v], i) => `${i + 1}. <@${id}> — ${v.xp} XP — niveau ${levelFor(v.xp)}`)
    .join("\n") || "Aucune donnée.";
  return interaction.reply({ embeds: [new EmbedBuilder().setTitle("Classement XP").setDescription(list)] });
}

export function addXp(userId, amount) {
  const db = loadDb();
  db.xp[userId] ??= { xp: 0 };
  db.xp[userId].xp += amount;
  saveDb(db);
  return levelFor(db.xp[userId].xp);
}

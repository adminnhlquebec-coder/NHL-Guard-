import { REST, Routes } from "discord.js";
import { config, requireConfig } from "./config.js";
import { allCommands } from "./commands/index.js";

requireConfig();

const rest = new REST({ version: "10" }).setToken(config.token);
await rest.put(
  Routes.applicationGuildCommands(config.clientId, config.guildId),
  { body: allCommands.map(c => c.toJSON()) }
);

console.log(`Commandes déployées sur le serveur ${config.guildId}.`);

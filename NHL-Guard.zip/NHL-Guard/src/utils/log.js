import { EmbedBuilder } from "discord.js";
import { config } from "../config.js";

export async function logEvent(guild, title, description, fields = []) {
  const channelId = config.logChannelId || guild?.client?.nhlConfig?.logChannelId;
  if (!channelId) return;
  const channel = guild?.channels?.cache?.get(channelId);
  if (!channel?.isTextBased()) return;

  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();

  if (fields.length) embed.addFields(fields);
  await channel.send({ embeds: [embed] }).catch(() => {});
}

import { PermissionFlagsBits } from "discord.js";

export function isModerator(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages) ||
         interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers) ||
         interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers);
}

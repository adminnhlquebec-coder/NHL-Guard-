import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "..", "..", "data");
const file = path.join(dataDir, "db.json");

const defaults = {
  warnings: {},
  invites: {},
  xp: {},
  giveaways: {},
  config: {}
};

export function loadDb() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify(defaults, null, 2));
    return structuredClone(defaults);
  }
  try {
    return { ...structuredClone(defaults), ...JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {
    return structuredClone(defaults);
  }
}

export function saveDb(db) {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(db, null, 2));
}

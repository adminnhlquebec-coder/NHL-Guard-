import "dotenv/config";

export const config = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  welcomeChannelId: process.env.WELCOME_CHANNEL_ID || null,
  goodbyeChannelId: process.env.GOODBYE_CHANNEL_ID || null,
  logChannelId: process.env.LOG_CHANNEL_ID || null,
  ticketCategoryId: process.env.TICKET_CATEGORY_ID || null,
  supportRoleId: process.env.SUPPORT_ROLE_ID || null,
  modRoleId: process.env.MOD_ROLE_ID || null,
  botName: process.env.BOT_NAME || "NHL Guard",
  xpPerMessage: Number(process.env.XP_PER_MESSAGE || 5),
  xpCooldownSeconds: Number(process.env.XP_COOLDOWN_SECONDS || 60),
  giveawayMinMembers: Number(process.env.GIVEAWAY_MIN_MEMBERS || 150)
};

export function requireConfig() {
  const missing = ["token", "clientId", "guildId"].filter(k => !config[k]);
  if (missing.length) {
    throw new Error(`Configuration manquante dans .env : ${missing.join(", ")}`);
  }
}

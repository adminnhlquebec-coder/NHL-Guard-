import {
  Client, GatewayIntentBits, Partials, Events,
  ChannelType, PermissionsBitField
} from "discord.js";
import { config, requireConfig } from "./config.js";
import { loadDb, saveDb } from "./utils/db.js";
import { logEvent } from "./utils/log.js";
import { allCommands } from "./commands/index.js";
import { handleModeration } from "./commands/moderation.js";
import { handleServer } from "./commands/server.js";
import { handleGiveaway } from "./commands/giveaway.js";
import { handleXp, addXp } from "./commands/xp.js";
import { handleNhl } from "./commands/nhl.js";

requireConfig();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

client.nhlConfig = config;

const inviteCache = new Map();
const xpCooldown = new Map();

client.once(Events.ClientReady, async ready => {
  console.log(`${config.botName} connecté en tant que ${ready.user.tag}.`);
  for (const guild of ready.guilds.cache.values()) {
    try {
      const invites = await guild.invites.fetch();
      inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses || 0])));
    } catch {}
  }
});

client.on(Events.GuildMemberAdd, async member => {
  const db = loadDb();

  let inviter = null;
  try {
    const before = inviteCache.get(member.guild.id) || new Map();
    const afterInvites = await member.guild.invites.fetch();
    const used = afterInvites.find(i => (i.uses || 0) > (before.get(i.code) || 0));
    if (used?.inviter) {
      inviter = used.inviter;
      db.invites[inviter.id] ??= { valid: 0 };
      db.invites[inviter.id].valid += 1;
    }
    inviteCache.set(member.guild.id, new Map(afterInvites.map(i => [i.code, i.uses || 0])));
    saveDb(db);
  } catch {}

  const channelId = config.welcomeChannelId || db.config[member.guild.id]?.welcomeChannelId;
  const channel = channelId ? member.guild.channels.cache.get(channelId) : null;
  if (channel?.isTextBased()) {
    await channel.send(`Bienvenue ${member} sur **${member.guild.name}** ! Nous sommes maintenant **${member.guild.memberCount}** membres.`);
  }
  await logEvent(member.guild, "Arrivée", `${member.user.tag} a rejoint le serveur.`, inviter ? [{ name: "Invité par", value: inviter.tag }] : []);
});

client.on(Events.GuildMemberRemove, async member => {
  const db = loadDb();
  const channelId = config.goodbyeChannelId || db.config[member.guild.id]?.welcomeChannelId;
  const channel = channelId ? member.guild.channels.cache.get(channelId) : null;
  if (channel?.isTextBased()) await channel.send(`**${member.user.tag}** a quitté le serveur.`);
  await logEvent(member.guild, "Départ", `${member.user.tag} a quitté le serveur.`);
});

client.on(Events.MessageCreate, async message => {
  if (!message.guild || message.author.bot) return;
  const now = Date.now();
  const last = xpCooldown.get(message.author.id) || 0;
  if (now - last >= config.xpCooldownSeconds * 1000) {
    xpCooldown.set(message.author.id, now);
    addXp(message.author.id, config.xpPerMessage);
  }
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (["ban","kick","timeout","warn","warnings","clear"].includes(interaction.commandName)) return handleModeration(interaction);
      if (["setup","serverinfo","userinfo","role","ticket","invites"].includes(interaction.commandName)) return handleServer(interaction);
      if (interaction.commandName === "giveaway") return handleGiveaway(interaction);
      if (["rank","leaderboard"].includes(interaction.commandName)) return handleXp(interaction);
      if (interaction.commandName === "nhl") return handleNhl(interaction);
    }

    if (interaction.isButton()) {
      const db = loadDb();

      if (interaction.customId === "giveaway_join") {
        const g = db.giveaways[interaction.message.id];
        if (!g || g.ended || Date.now() > g.endsAt) return interaction.reply({ content: "Ce giveaway est terminé.", ephemeral: true });
        if (g.entries.includes(interaction.user.id)) return interaction.reply({ content: "Tu participes déjà.", ephemeral: true });
        g.entries.push(interaction.user.id);
        saveDb(db);
        return interaction.reply({ content: "Participation enregistrée.", ephemeral: true });
      }

      if (interaction.customId === "ticket_support") {
        const existing = interaction.guild.channels.cache.find(c => c.name === `ticket-${interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 18)}`);
        if (existing) return interaction.reply({ content: `Tu as déjà un ticket : ${existing}`, ephemeral: true });

        const supportRole = config.supportRoleId ? interaction.guild.roles.cache.get(config.supportRoleId) : null;
        const overwrites = [
          { id: interaction.guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }
        ];
        if (supportRole) overwrites.push({ id: supportRole.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] });

        const channel = await interaction.guild.channels.create({
          name: `ticket-${interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 18)}`,
          type: ChannelType.GuildText,
          parent: config.ticketCategoryId || undefined,
          permissionOverwrites: overwrites
        });
        await channel.send(`Ticket de ${interaction.user}. Explique ta demande ici.`);
        return interaction.reply({ content: `Ticket créé : ${channel}`, ephemeral: true });
      }
    }
  } catch (error) {
    console.error(error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: "Une erreur est survenue.", ephemeral: true }).catch(() => {});
    }
  }
});

client.login(config.token);

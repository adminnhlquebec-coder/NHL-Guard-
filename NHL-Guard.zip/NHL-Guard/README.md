# NHL Guard

Bot Discord complet pour un serveur NHL.

## Fonctions incluses

- Modération : ban, kick, timeout, warn, clear, historique des sanctions
- Tickets avec catégories et fermeture
- Giveaways avec bouton de participation
- Gestion des invitations et suivi des invitations valides
- Compteur de membres
- Bienvenue / départ
- Logs de modération et événements
- Commandes slash
- Gestion des rôles
- XP et niveaux
- Pronostics NHL
- Scores NHL en direct / derniers résultats
- Classement NHL
- Informations NHL
- Configuration dans `.env`
- Données persistantes dans `data/`
- Structure prête pour GitHub et l'hébergement

## Installation

1. Installe Node.js 24 ou plus récent.
2. Décompresse le ZIP.
3. Ouvre un terminal dans le dossier.
4. Lance :
   `npm install`
5. Copie `.env.example` vers `.env`.
6. Mets ton token Discord dans `.env`.
7. Mets `CLIENT_ID` et `GUILD_ID`.
8. Dans le Developer Portal, active les intents privilégiés nécessaires à ton serveur (notamment Server Members pour le suivi des arrivées/départs et des invitations).
9. Déploie les commandes :
   `npm run deploy`
10. Démarre le bot :
   `npm start`

## Important

Ne partage jamais ton token Discord. Il doit rester uniquement dans `.env`.

Les intents privilégiés sont contrôlés par Discord. Pour une application de moins de 10 000 utilisateurs, ils peuvent actuellement être activés depuis le Developer Portal; au-delà, Discord prévoit une procédure de revue. Voir la documentation officielle de Discord.

## Commandes principales

### Modération
- `/ban`
- `/kick`
- `/timeout`
- `/warn`
- `/warnings`
- `/clear`

### Serveur
- `/setup`
- `/serverinfo`
- `/userinfo`
- `/role`
- `/ticket`
- `/invites`

### Giveaway
- `/giveaway create`
- `/giveaway end`

### XP
- `/rank`
- `/leaderboard`

### NHL
- `/nhl scores`
- `/nhl standings`
- `/nhl info`
- `/nhl predict`

## Configuration

`/setup` crée/configure automatiquement plusieurs éléments de base du serveur. Tu peux ensuite ajuster les IDs dans `.env`.

Le fichier `data/db.json` est créé automatiquement au premier démarrage.
